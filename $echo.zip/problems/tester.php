<?php
/*
	Original submitter by Tareq Hasan (http://tareq.wedevs.com/page/5/)
*/
error_reporting(0);
session_start();
include('../dbset.php');
$user = 'edos';
$pass = '01011011';
$code = '';
$input = '';
$run = true;
$private = false;

$subStatus = array(
    0 => 'Success',
    1 => 'Compiled',
    3 => 'Running',
    11 => 'Compilation Error',
    12 => 'Runtime Error',
    13 => 'Timelimit exceeded',
    15 => 'Success',
    17 => 'memory limit exceeded',
    19 => 'illegal system call',
    20 => 'internal error'
);

$error = array(
    'status' => 'error',
    'output' => 'Something went wrong :('
);

if ( isset( $_POST['process'] ) && $_POST['process'] == 1 ) {
    $lang = isset( $_POST['lang'] ) ? intval( $_POST['lang'] ) : 1;
    $code = trim( $_POST['source'] );
    $pid = $_POST['pid'];
    $uid = $_POST['uid'];

    function duplicateAnswer($uid, $pid, $time, $language){
		$sql="select count(id) as dups from submissions where (user_id=$uid and problem_id=$pid and runtime='$runtime' and language='$language')";
		$result = mysql_query($sql);
		while($rows = mysql_fetch_query($result)){
			$count = $rows['dups'];
		}
		return $count;
    }
    
	$sql="SELECT * FROM questions where id=$pid";
	$result=mysql_query($sql); 
	while($rows=mysql_fetch_array($result)){
		$input = $rows['testcases'];
		$correctAnswer = $rows['correctAnswer'];
	}
    $client = new SoapClient( "http://ideone.com/api/1/service.wsdl" );

    //create new submission
    $result = $client->createSubmission( $user, $pass, $code, $lang, $input, $run, $private );

    //if submission is OK, get the status
    if ( $result['error'] == 'OK' ) {
        $status = $client->getSubmissionStatus( $user, $pass, $result['link'] );
        if ( $status['error'] == 'OK' ) {

            //check if the status is 0, otherwise getSubmissionStatus again
            while ( $status['status'] != 0 ) {
                sleep( 3 ); //sleep 3 seconds
                $status = $client->getSubmissionStatus( $user, $pass, $result['link'] );
            }

            //finally get the submission results
            $details = $client->getSubmissionDetails( $user, $pass, $result['link'], true, true, true, true, true );
            if ( $details['error'] == 'OK' ) {
                //print_r( $details );
                if ( $details['status'] < 0 ) {
                    $status = 'waiting for compilation';
                } else {
                    $status = $subStatus[$details['status']];
                }
				$uid = $_SESSION['id'];
				$time = $details['time']."s";

				switch($lang){
					case 7: $language="Ada (gnat-4.3.2)"; break;
                    case 13: $language="Assembler (nasm-2.07)"; break;
                    case 45: $language="Assembler (gcc-4.3.4)"; break;
                    case 104: $language="AWK (gawk) (gawk-3.1.6)"; break;
                    case 105: $language="AWK (mawk) (mawk-1.3.3)"; break;
                    case 28: $language="Bash (bash 4.0.35)"; break;
                    case 110: $language="bc (bc-1.06.95)"; break;
                    case 12: $language="Brainf**k (bff-1.0.3.1)"; break;
                    case 11: $language="C (gcc-4.3.4)"; break;
                    case 27: $language="C# (mono-2.8)"; break;
                    case 1: $language="C++ (gcc-4.3.4)"; break;
                    case 44: $language="C++0x (gcc-4.5.1)"; break;
                    case 34: $language="C99 strict (gcc-4.3.4)"; break;
                    case 14: $language="CLIPS (clips 6.24)"; break;
                    case 111: $language="Clojure (clojure 1.1.0)"; break;
                    case 118: $language="COBOL (open-cobol-1.0)"; break;
                    case 106: $language="COBOL 85 (tinycobol-0.65.9)"; break;
                    case 32: $language="Common Lisp (clisp) (clisp 2.47)"; break;
                    case 102: $language="D (dmd) (dmd-2.042)"; break;
                    case 36: $language="Erlang (erl-5.7.3)"; break;
                    case 124: $language="F# (fsharp-2.0.0)"; break;
                    case 123: $language="Factor (factor-0.93)"; break;
                    case 125: $language="Falcon (falcon-0.9.6.6)"; break;
                    case 107: $language="Forth (gforth-0.7.0)"; break;
                    case 5: $language="Fortran (gfortran-4.3.4)"; break;
                    case 114: $language="Go (gc-2010-07-14)"; break;
                    case 121: $language="Groovy (groovy-1.7)"; break;
                    case 21: $language="Haskell (ghc-6.8.2)"; break;
                    case 16: $language="Icon (iconc 9.4.3)"; break;
                    case 9: $language="Intercal (c-intercal 28.0-r1)"; break;
                    case 10: $language="Java (sun-jdk-1.6.0.17)"; break;
                    case 35: $language="JavaScript (rhino) (rhino-1.6.5)"; break;
                    case 112: $language="JavaScript (spidermonkey) (spidermonkey-1.7)"; break;
                    case 26: $language="Lua (luac 5.1.4)"; break;
                    case 30: $language="Nemerle (ncc 0.9.3)"; break;
                    case 25: $language="Nice (nicec 0.9.6)"; break;
                    case 122: $language="Nimrod (nimrod-0.8.8)"; break;
                    case 43: $language="Objective-C (gcc-4.5.1)"; break;
                    case 8: $language="Ocaml (ocamlopt 3.10.2)"; break;
                    case 119: $language="Oz (mozart-1.4.0)"; break;
                    case 22: $language="Pascal (fpc) (fpc 2.2.0)"; break;
                    case 2: $language="Pascal (gpc) (gpc 20070904)"; break;
                    case 3: $language="Perl (perl 5.12.1)"; break;
                    case 54: $language="Perl 6 (rakudo-2010.08)"; break;
                    case 29: $language="PHP (php 5.2.11)"; break;
                    case 19: $language="Pike (pike 7.6.86)"; break;
                    case 108: $language="Prolog (gnu) (gprolog-1.3.1)"; break;
                    case 15: $language="Prolog (swi) (swipl 5.6.64)"; break;
                    case 4: $language="Python (python 2.6.4)"; break;
                    case 116: $language="Python 3 (python-3.1.2)"; break;
                    case 117: $language="R (R-2.11.1)"; break;
                    case 17: $language="Ruby (ruby-1.9.2)"; break;
                    case 39: $language="Scala (scala-2.8.0.final)"; break;
                    case 33: $language="Scheme (guile) (guile 1.8.5)"; break;
                    case 23: $language="Smalltalk (gst 3.1)"; break;
                    case 40: $language="SQL (sqlite3-3.7.3)"; break;
                    case 38: $language="Tcl (tclsh 8.5.7)"; break;
                    case 62: $language="Text (text 6.10)"; break;
                    case 115: $language="Unlambda (unlambda-2.0.0)"; break;
                    case 101: $language="Visual Basic .NET (mono-2.4.2.3)"; break;
                    case 6: $language="Whitespace (wspace 0.3)"; break;
				}
                $time=substr($time, 0, strlen($time)-1);
                $correctAnswer=trim($correctAnswer);
                $correctAnswer=preg_replace("/[^A-Za-z0-9 ]/", '', $correctAnswer);
                $userOutput=trim($details['output']);
                $userOutput=preg_replace("/[^A-Za-z0-9 ]/", '', $userOutput);
                $code = htmlspecialchars($code);
                if( strcmp($correctAnswer, $userOutput)==0 ){
					$dbresult = "Success";
					$insertSql = "insert into submissions(user_id, problem_id, status, runtime, dateSubmitted, language, sourceCode) values($uid,$pid,'$dbresult','$time', Now(), '$language', '$code')";
				}
				else{
					$dbresult = "Fail";
					$insertSql = "insert into submissions(user_id, problem_id, status, runtime, dateSubmitted, language, sourceCode) values($uid,$pid,'$dbresult','$time', Now(), '$language', '$code')";
				}

				$dup=duplicateAnswer($uid, $pid, $time, $language);
				if( $dup<=0 ){ 
					mysql_query($insertSql)or die("Incorrect query: ".$insertSql);
					$dbResult=$insertSql;
				}
				if($dup>0)
					$dbresult = "Error: Detected a duplicate runtime to the problem. Will not submit solution.";			

                $data = array(
                	'testcases' => $input,
		    		'pid' => $pid,
                    'status' => 'success',
                    'meta' => "Memory: {$details['memory']} | Time: {$details['time']}s",
                    'output' => htmlspecialchars( $dbresult ),
                    'raw' => $details
                );
                
                if( $details['cmpinfo'] ) {
                    $data['cmpinfo'] = $details['cmpinfo'];
                }
                
                echo json_encode( $data );
            } else {
                //we got some error :(
                //print_r( $details );
                echo json_encode( $error );
            }
        } else {
            //we got some error :(
            echo json_encode( $error );
        }
    } else {
        //we got some error :(
        echo json_encode( $error );
    }
}