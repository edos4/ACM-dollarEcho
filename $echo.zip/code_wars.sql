-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 15, 2013 at 06:41 AM
-- Server version: 5.5.31
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `code.wars`
--
CREATE DATABASE IF NOT EXISTS `code.wars` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `code.wars`;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `correctAnswer` tinytext NOT NULL,
  `title` text NOT NULL,
  `testcases` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `correctAnswer`, `title`, `testcases`) VALUES
(1, 'kjsdflkjsdflkj\n\n', 'A', '1', 'wer\nsf\nxv\ng\nfgert\nsfs\ndf'),
(2, '1+1', 'A', '2', '7, 8, 9, 10, 11, 12'),
(3, '3+3', 'C', '3', '13, 14, 15, 16, 17, 18, 19'),
(4, 'kalabaw', 'A', '4', '20, 21, 22, 23, 24, 25, 26, 27, 28'),
(5, 'kanin', 'C', '5', '29, 30, 31'),
(6, 'ibon', 'C', '6', '32, 33'),
(7, 'kompyuter', 'B', '7', '34, 35, 36, 37, 38, 39'),
(8, 'sapatos', 'C', '8', '40,41, 42, 43, 44'),
(21, 'kjsdflkjsdflkj\n\n', 'A', '1', '1, 2, 3, 4, 5, 6'),
(22, '1+1', '1wer\n2sf\n3xv\n4g\n5fgert\n6sfs\n7df', '2', 'wer\nsf\nxv\ng\nfgert\nsfs\ndf'),
(23, '3+3', 'C', '3', '13, 14, 15, 16, 17, 18, 19'),
(24, 'kalabaw', 'A', '4', '20, 21, 22, 23, 24, 25, 26, 27, 28'),
(25, 'kanin', 'C', '5', '29, 30, 31'),
(26, 'ibon', 'C', '6', '32, 33'),
(27, 'kompyuter', 'B', '7', '34, 35, 36, 37, 38, 39'),
(28, 'sapatos', 'C', '8', '40,41, 42, 43, 44');

-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

CREATE TABLE IF NOT EXISTS `submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `problem_id` int(11) NOT NULL,
  `status` text NOT NULL,
  `runtime` text NOT NULL,
  `dateSubmitted` datetime NOT NULL,
  `language` text NOT NULL,
  `sourceCode` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `submissions`
--

INSERT INTO `submissions` (`id`, `user_id`, `problem_id`, `status`, `runtime`, `dateSubmitted`, `language`, `sourceCode`) VALUES
(1, 2, 23, 'Fail', '0s', '2013-11-14 18:25:46', 'C++ (gcc-4.3.4)', 'sfDvesthbdnflm;,ihg'),
(2, 2, 22, 'Success', '0s', '2013-11-14 18:34:04', 'C++ (gcc-4.3.4)', 'xdzxbcnb'),
(3, 2, 22, 'Fail', '0s', '2013-11-14 18:38:11', 'Java (sun-jdk-1.6.0.17)', 'sfdsdgngjh'),
(4, 2, 22, 'Fail', '0.07s', '2013-11-14 18:39:13', 'Java (sun-jdk-1.6.0.17)', 'import java.io.*;\nclass Ideone\n{\n	public static void main (String[] args) throws java.lang.Exception\n	{\n		BufferedReader r = new BufferedReader (new InputStreamReader (System.in));\n		String s;\n		while (!(s=r.readLine()).startsWith("42")) System.out.println(s);\n	}\n}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `password` text NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `privilege` int(11) NOT NULL,
  `email` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fname`, `lname`, `privilege`, `email`) VALUES
(1, 'Admin', 'admin', 'Admin', 'Istratorhaha', 0, 'admin@this.com'),
(2, 'eybi', 'eybimonkey', 'Maria Angelica', 'Villaverde', 2, 'eybi@exam.com'),
(4, '<script>alert("noob");</s', 'profone', '<script>alert(noob);</script>', 'One', 1, 'killyourbrain@yahoo.com'),
(47, 'proftwo', 'proftwo', 'Professor', 'Two', 1, '');
